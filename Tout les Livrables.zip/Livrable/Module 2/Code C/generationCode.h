#ifndef CODE_C_GENERATIONCODE_H
#define CODE_C_GENERATIONCODE_H
#include <stdio.h>
#include <stdlib.h>
void envoyerparam(char, char);
#endif //CODE_C_GENERATIONCODE_H
