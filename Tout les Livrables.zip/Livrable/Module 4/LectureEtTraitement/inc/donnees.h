//
// Created by Etienne on 09/11/2018.
//

#ifndef LECTUREETTRAITEMENT_DONNEES_H
#define LECTUREETTRAITEMENT_DONNEES_H

#include "general.h"

int tailleDonnees();
void extraireDonnees(Informations *, int);

#endif //LECTUREETTRAITEMENT_DONNEES_H
