//
// Created by Etienne on 09/11/2018.
//

#ifndef LECTUREETTRAITEMENT_MENU_H
#define LECTUREETTRAITEMENT_MENU_H

#include "general.h"

void menuPrincipal();
void menuOrdre();

#endif //LECTUREETTRAITEMENT_MENU_H
