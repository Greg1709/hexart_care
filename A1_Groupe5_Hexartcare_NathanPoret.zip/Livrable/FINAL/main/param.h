#define MODE 4
#define CHOIX 0
