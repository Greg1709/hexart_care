#ifndef CODE_C_MENU_H
#define CODE_C_MENU_H
#define TAILLE 9
void menu(char *, char *);
int checkNumber(char[]);
#endif //CODE_C_MENU_H
