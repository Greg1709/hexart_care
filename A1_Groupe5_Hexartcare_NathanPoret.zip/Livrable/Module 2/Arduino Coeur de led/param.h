#define MODE 6
#define CHOIX 0
